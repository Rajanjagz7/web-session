# Fieldr Customer Logos (Full HD Roster)

A complete collection of **150 verified customer & enterprise partner logos** in **1920×1080 Full HD (1080p)** resolution and scalable **Vector SVG** format, specially tailored for the **Fieldr** platform (Field Operations, Job Dispatch, Workforce Management, Facilities, Logistics & Industrial Equipment).

## Package Contents

- **`png/`**: 150 Full HD (1920×1080) transparent background PNGs with crisp vector-rendered clarity and proportional padding.
- **`svg/`**: 150 Original Scalable Vector Graphics (SVG) with official brand colors.
- **`customers.json`**: Structured database mapping each customer's name, sector/industry, website, official hex brand color, and relative file paths.
- **`preview.html`** / **`index.html`**: Interactive showcase gallery to preview, search, test on dark/slate/light/checker backgrounds, copy code snippets, and download individual logos.
- **`fieldr-customer-logos-fullhd.zip`**: The full compressed archive containing all assets.

## Industries Represented

1. **Heavy Equipment & Industrial Automation**: Caterpillar, Siemens, Bosch, Schneider Electric, John Deere, ABB, General Electric, Hitachi, Mitsubishi, 3M, Airbus, Boeing, Sony, Panasonic, Samsung, LG, Sharp, Abbott, AbbVie, Accenture, ADP, Fujitsu, Acer, Honeywell, Toshiba
2. **Logistics, Freight & Aviation Fleet**: FedEx, DHL, UPS, Deutsche Post, AfterShip, Singapore Airlines, Delta, United Airlines, Lufthansa, Air France, British Airways, American Airlines, KLM, Qatar Airways, Emirates, Air Canada, Qantas, ANA, Japan Airlines, Turkish Airlines, Iberia, Air India, Southwest Airlines, Ryanair, easyJet
3. **Automotive & Commercial Vehicles**: Tesla, Toyota, BMW, Ford, Volvo, Hyundai, Kia, Audi, Porsche, Nissan, Honda, Chevrolet, Jeep, Renault, Peugeot, Subaru, Mazda, General Motors, Suzuki, Ferrari, Lamborghini, Aston Martin, Bentley, Bugatti, Maserati
4. **Energy, Utilities, Telecom & Services**: Shell, Vodafone, Orange, Telefónica, BT, Airtel, TCS, Infosys, Wipro, Uber, Lyft, Booking.com, Expedia, Tripadvisor, Airbnb, Motorola Solutions, Garmin, Bose, Epson, Nikon, Fujifilm, Adyen, Klarna, eBay, Netflix
5. **Enterprise Cloud, Tech & Hardware**: Microsoft, Google Cloud, AWS, Amazon, Apple, Cisco, IBM, Intel, AMD, NVIDIA, Oracle, Salesforce, SAP, Dell Technologies, HP Enterprise, Lenovo, Qualcomm, Broadcom, VMware, Red Hat, Splunk, Snowflake, Datadog, Cloudflare, Stripe
6. **Modern SaaS, Operations & Developer Platforms**: Shopify, Slack, Zoom, Atlassian, Jira, Confluence, Trello, GitHub, GitLab, Docker, Kubernetes, HashiCorp, Terraform, Ansible, Jenkins, Sentry, New Relic, Dynatrace, Grafana, Prometheus, MongoDB, Redis, PostgreSQL, MySQL, Supabase

## Quick Integration Guide

### 1. In HTML Customer Showcase / Logo Carousel
```html
<!-- Example Customer Logo Grid in Fieldr -->
<div class="customer-logo-item">
  <img src="assets/customers/caterpillar.png" alt="Caterpillar" width="160" height="90" loading="lazy">
</div>
<div class="customer-logo-item">
  <img src="assets/customers/siemens.png" alt="Siemens" width="160" height="90" loading="lazy">
</div>
<div class="customer-logo-item">
  <img src="assets/customers/fedex.png" alt="FedEx" width="160" height="90" loading="lazy">
</div>
```

### 2. In JavaScript / Dynamic Render (React, Vue, Vanilla)
```javascript
// Fetch customers.json
const response = await fetch('assets/customers/customers.json');
const customers = await response.json();

// Render into logo marquee / customer grid
const grid = document.querySelector('.customer-grid');
grid.innerHTML = customers.map(c => `
  <div class="customer-card" title="${c.name} - ${c.category}">
    <img src="${c.pngFile}" alt="${c.name} Logo" loading="lazy" />
  </div>
`).join('');
```
