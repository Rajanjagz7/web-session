# QA Skills Bundle for Claude Code

Two skills that work together: **QA Agent** runs the explore → generate → run →
heal → report loop, and **Test Data Generation** gives it patterns (Faker,
factories, builders, seeding) for the "generate" step.

## What's inside

```
.claude/
  skills/
    qa-agent-claude/
      SKILL.md
    test-data-generation/
      SKILL.md
```

## Install

Copy the `.claude/skills/` folder into the root of your project (merge with
an existing `.claude/skills/` directory if you already have one):

```bash
cp -r .claude/skills/* /path/to/your-project/.claude/skills/
```

Claude Code auto-discovers skills under `.claude/skills/<name>/SKILL.md` —
no further registration needed. Once copied, ask Claude Code to "act as a
QA agent" or "test this app" and it will follow the QA Agent loop, pulling
in the Test Data Generation patterns whenever it needs to generate factories,
builders, or seeded fixtures.

## Skills

- **qa-agent-claude** — autonomous QA loop (explore, derive journeys,
  generate tests, run, triage, self-heal, report). Playwright-based.
- **test-data-generation** — Faker.js/Python/Java data generation, factory
  and builder patterns, DB seeding, and test-data anti-patterns to avoid.
