importScripts('https://bcppqf-4m.myshopify.com/cdn/wpm/s1a9baebawdc64f25fp260b5808mb1d3394fl.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('shopify-app-pixel', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-shopify-app-pixel@0520.js');
