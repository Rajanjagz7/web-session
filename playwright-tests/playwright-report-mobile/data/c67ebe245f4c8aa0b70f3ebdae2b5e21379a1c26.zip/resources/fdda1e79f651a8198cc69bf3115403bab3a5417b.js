import{u as r}from"./4b4bc88f.cgIhnW4J.js";import{P as o}from"./164ad2e3.BQn9Y2Td.js";function s(){return r(o)}export{s as u};
