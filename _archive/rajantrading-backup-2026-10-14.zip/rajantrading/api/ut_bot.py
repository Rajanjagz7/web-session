"""UT Bot and related utility functions for indicators."""


def _true_range(high, low, close_prev):
    """Calculate True Range for ATR."""
    tr1 = high - low
    tr2 = abs(high - close_prev) if close_prev else 0
    tr3 = abs(low - close_prev) if close_prev else 0
    return max(tr1, tr2, tr3)


def _rma(values, period):
    """Calculate RMA (EMA with alpha=1/period)."""
    if not values or len(values) < period:
        return None
    alpha = 1.0 / period
    rma_val = values[0]
    for val in values[1:]:
        rma_val = alpha * val + (1 - alpha) * rma_val
    return rma_val


def fetch_index_history(symbol, days=252, lookback_days=None):
    """Real daily OHLCV bars (oldest first) from Upstox.

    Returns [] when Upstox is not configured, the symbol has no Upstox
    instrument (e.g. BITCOIN/CRUDEOIL/GOLD) or the request fails -- never
    synthetic prices, so callers can't mistake fake candles for real ones.
    """
    from datetime import datetime, timedelta, timezone
    lookback = int(lookback_days if lookback_days is not None else days)
    try:
        try:
            from .upstox_service import upstox_service
        except ImportError:
            from upstox_service import upstox_service
        if not upstox_service.is_configured():
            return []
        sym = str(symbol).upper().strip()
        key = upstox_service.INDEX_KEYS.get(sym)
        if not key:
            key, _ = upstox_service._resolve_underlying(sym)
        ist = timezone(timedelta(hours=5, minutes=30))
        to_d = datetime.now(ist).date()
        # Upstox's daily endpoint serves long ranges; add slack for weekends/holidays.
        from_d = to_d - timedelta(days=int(lookback * 1.6) + 10)
        candles = upstox_service.fetch_historical_candles(
            key, "days", "1", to_d.isoformat(), from_d.isoformat()
        )
    except Exception as e:
        print(f"[ut_bot] fetch_index_history failed for {symbol}: {e}")
        return []
    bars = [{
        "date": str(c["time"])[:10],
        "open": c["open"], "high": c["high"], "low": c["low"],
        "close": c["close"], "volume": c["volume"],
    } for c in candles]
    return bars[-lookback:]
